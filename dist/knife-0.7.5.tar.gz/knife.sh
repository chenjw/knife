#!/bin/bash
java -cp .:lib/commons-collections-3.2.1.jar:lib/commons-io-1.4.jar:lib/commons-lang-2.4.jar:lib/commons-logging-1.1.1.jar:lib/jline-1.0.jar:lib/fastjson-1.1.17.jar:lib/knife-client.jar:$JAVA_HOME/lib/tools.jar com.chenjw.knife.client.ClientMain $*
